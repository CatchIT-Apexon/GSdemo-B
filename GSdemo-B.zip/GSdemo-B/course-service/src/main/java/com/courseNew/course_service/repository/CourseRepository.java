package com.courseNew.course_service.repository;

import com.courseNew.course_service.entity.Course;
import com.courseNew.course_service.entity.CourseCategory;
import com.courseNew.course_service.projection.CourseProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Integer> {
    List<Course> findByCategory(CourseCategory category);
}

