package com.courseNew.course_service.projection;

public interface CourseProjection {
    String getCourseName();
    String getCategory();
}
