package com.courseNew.course_service.entity;

public enum CourseCategory {
    TECHNICAL("Technical", "Courses related to technical skills like programming, data science, etc."),
    NON_TECHNICAL("Non-Technical", "Courses related to soft skills, business, etc."),
    MANAGEMENT("Management", "Courses related to management and leadership."),
    DESIGN("Design", "Courses related to creative and design skills like graphic design, UI/UX, etc."),
    MARKETING("Marketing", "Courses related to marketing, advertising, and sales.");

    private String name;
    private String description;

    CourseCategory(String name, String description) {
        this.name = name;
        this.description = description;
    }

    // Getters
}

