package com.courseNew.course_service.entity;

public enum DeliveryMethod {
    ONLINE,
    CLASSROOM;
}

