package com.courseNew.course_service.dto;


public class InstructorDTO {

    private Integer instructorId;
    private String name;
    private String expertise;
    private String bio;
    private String email;

    // Getters and Setters
}
