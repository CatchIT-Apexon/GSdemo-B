package com.courseNew.course_service.service;

import com.courseNew.course_service.dto.CourseDTO;
import com.courseNew.course_service.dto.InstructorDTO;
import com.courseNew.course_service.entity.Course;
import com.courseNew.course_service.entity.CourseCategory;
import com.courseNew.course_service.repository.CourseRepository;
import lombok.Data;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
@Data
public class CourseService {
    @Autowired
    private CourseRepository courseRepository;

    public Course createCourse(CourseDTO courseDTO) {
        Course course = new Course();
        course.setCourseName(courseDTO.getCourseName());
        course.setProductDescription(courseDTO.getProductDescription());
        course.setDuration(courseDTO.getDuration());
        course.setCategory(courseDTO.getCategory());
        course.setDeliveryMethod(courseDTO.getDeliveryMethod());
        return courseRepository.save(course);
    }

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public List<Course> getCoursesByCategory(CourseCategory category) {
        return courseRepository.findByCategory(category);
    }
}
