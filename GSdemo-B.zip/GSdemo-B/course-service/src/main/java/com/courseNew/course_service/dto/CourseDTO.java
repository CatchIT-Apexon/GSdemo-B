package com.courseNew.course_service.dto;

import com.courseNew.course_service.entity.CourseCategory;
import com.courseNew.course_service.entity.DeliveryMethod;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CourseDTO {
    private String courseName;
    private String productDescription;
    private Integer duration;
    private CourseCategory category;
    private DeliveryMethod deliveryMethod;

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public CourseCategory getCategory() {
        return category;
    }

    public void setCategory(CourseCategory category) {
        this.category = category;
    }

    public DeliveryMethod getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(DeliveryMethod deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }
// Getters and Setters
}
